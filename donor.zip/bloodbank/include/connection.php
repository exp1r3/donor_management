<?php

$db_name="blood_bank";
$db_user="root";
$db_pass="";
$db_host="localhost";

$connection=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
// if(!$connection){
	// die("Connection Fail".$connection->connect_error);
// }
// else{
// 	echo"Connected";
// }
?>
