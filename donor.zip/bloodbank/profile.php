
<?php
require  __DIR__.'\include\connection.php';
session_start();
if(!isset($_SESSION['email'])){
  echo"<script>window.location='login.php'</script>";
}
else{
$email=$_SESSION['email'];
$password=$_SESSION['password'];
}

//require 'C:\xampp\htdocs\bloodbank\include\connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$age=$_POST['age'];
$email_new=$_POST['email'];
$password=$_POST['password'];
$phone=$_POST['phone'];

$update_data="UPDATE donor SET first_name='$first_name', last_name='$last_name', age='$age', email='$email_new', password='$password', phone='$phone' WHERE email='$email' ";
$connection->query($update_data);
if($email!=$email_new){
  echo"<script>window.location='login.php'</script>";
}
}
$statement="SELECT * FROM donor WHERE email='$email' AND password='$password'";
$login=$connection->query($statement);
$row=$login->fetch_assoc();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Donor Profile Update</title>
    <meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="include/css/style.css">

    <!-- Icons font CSS-->


    <link href="include/css/register_css/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="include/css/register_css/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- include/css/register_css/vendor CSS-->
    <link href="include/css/register_css/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="include/css/register_css/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="include/css/register_css/css/main.css" rel="stylesheet" media="all">
</head>

<body>
  <div class="nav">
  <input type="checkbox" id="nav-check">
  <div class="nav-header">
    <div class="nav-title">
      DonorManagement
    </div>
  </div>
  <div class="nav-btn">
    <label for="nav-check">
      <span></span>
      <span></span>
      <span></span>
    </label>
  </div>

  <div class="nav-links">
    <a href="profile.php" target="_blank">Profile</a>
    <a href="login.php" target="_blank">login</a>
    <a href="reg.php" target="_blank">Register</a>
    <a href="#" target="_blank">Find Donor</a>
    <a href="logout.php" target="_blank">Logout</a>
  </div>
</div>
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body">
                    <h2 class="title">Update Profile</h2>
                    <form action="profile.php" method="POST">

                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">first name</label>
                                    <input class="input--style-4" type="text" name="first_name" value="<?php echo $row['first_name']?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">last name</label>
                                    <input class="input--style-4" type="text" name="last_name" value="<?php echo $row['last_name']?>">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">

                                    <div class="input-group-icon">
                                      <label class="label">AGE</label>
                                      <input class="input--style-4" type="text" name="age"value="<?php echo $row['age']?>">
                                    </div>
                                </div>
                            </div>
                        <!-- <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Birthday</label>
                                    <div class="input-group-icon">
                                        <input class="input--style-4 js-datepicker" type="text" name="birthday">
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                            </div> -->
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Gender</label>
                                    <div class="p-t-10">
                                        <label class="radio-container m-r-45"><?php echo $row['gender']?>
                                            <input type="radio" checked="checked" name="gender" value="<?php echo $row['gender']?>">
                                            <span class="checkmark"></span>
                                        </label>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Email</label>
                                    <input class="input--style-4" type="email" name="email" value="<?php echo $row['email']?>">
                                </div>
                            </div>
							<div class="col-2">
                                <div class="input-group">
                                    <label class="label" >Password</label>
                                    <input class="input--style-4" type="password" placeholder="Change Password" name="password" value="<?php echo $row['password']?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Phone Number</label>
                                    <input class="input--style-4" type="text" name="phone" value="<?php echo $row['phone']?>">
                                </div>
                            </div>
                        </div>
                        <div class="input-group">
                            <label class="label">Blood Group</label>
                            <div class="rs-select2 js-select-simple select--no-search">
                                <select name="blood_group_disable">
                                    <option disabled="disabled" selected="selected"><?php if($row['blood_group']="oNeg"){
                										  echo "O-";
                										}
                										elseif ($row['blood_group']="oPos"){
                										  echo "O+";
                										}
                										elseif ($row['blood_group']="aNeg"){
                										  echo "A-";
                										}
                										elseif ($row['blood_group']="aPos"){
                										  echo "A+";
                										}
                										elseif ($row['blood_group']="bNeg"){
                										  echo "B-";
                										}
                										elseif ($row['blood_group']="bPos"){
                										  echo "B+";
                										}
                										elseif ($row['blood_group']="abNeg"){
                										  echo "AB-";
                										}
                										elseif ($row['blood_group']="abPos"){
                										  echo "AB+";
                										}
                										else{
                										  echo "Go To Hell, Where You Belongs!";
                										};?></option>
                                </select>
                                <div class="select-dropdown"></div>
                            </div>
                        </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update Info</button>
                        </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="button"><a href="logout.php">Logout</a></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="include/css/register_css/vendor/jquery/jquery.min.js"></script>
    <!-- include/css/register_css/vendor JS-->
    <script src="include/css/register_css/vendor/select2/select2.min.js"></script>
    <script src="include/css/register_css/vendor/datepicker/moment.min.js"></script>
    <script src="include/css/register_css/vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="include/css/style.js"></script>
    <script src="include/css/register_css/js/global.js"></script>


</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->
