<html>
<head>
	<title>DonorManagement</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="include/css/nav.css">

<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="include/css/login_css/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/css/util.css">
	<link rel="stylesheet" type="text/css" href="include/css/login_css/css/main.css">
<!--===============================================================================================-->
</head>
<body>
  <main class="site-wrapper">
    <div class="pt-table desktop-768">
      <div class="pt-tablecell page-home relative" style="background-image: url(https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1500&q=80);
      background-position: center;
      background-size: cover;">
                      <div class="overlay"></div>

                      <div class="container">
                          <div class="row">
                              <div class="col-xs-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
                                  <div class="page-title  home text-center">
                                    <span class="heading-page"> Find The Donor Available Right Now.
                                    </span>
                                      <p class="mt20">Select the blood group and we will show a list of avilable donor.</p>
                                  </div>

                                  <div class="hexagon-menu clear">
                                      <div class="hexagon-item">
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <a href="donor.php?bloodType=oNeg" target="_blank" class="hex-content">
                                              <span class="hex-content-inner">
                                                  <span class="icon">
                                                    <img src="include/img/neg.png"/>                                                  </span>
                                                  <span class="title">O-</span>
                                              </span>
                                              <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                          </a>
                                      </div>
                                      <div class="hexagon-item">
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <a href="donor.php?bloodType=oPos" target="_blank" class="hex-content">
                                              <span class="hex-content-inner">
                                                  <span class="icon">
                                                      <img src="include/img/pos.png"/>
                                                      <span class="title">O+</span>
                                                  </span>
                                              </span>
                                              <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                          </a>
                                      </div>
                                      <div class="hexagon-item">
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <a href="donor.php?bloodType=aNeg" target="_blank" class="hex-content">
                                              <span class="hex-content-inner">
                                                  <span class="icon">
                                                      <img src="include/img/neg.png"/>
                                                      <span class="title">A-</span>
                                                  </span>
                                              </span>
                                              <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                          </a>
                                      </div>
                                      <div class="hexagon-item">
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <a href="donor.php?bloodType=aPos" target="_blank" class="hex-content">
                                              <span class="hex-content-inner">
                                                  <span class="icon">
                                                    <img src="include/img/pos.png"/>
                                                    <span class="title">A+</span>
                                                  </span>
                                              </span>
                                              <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                          </a>
                                      </div>
                                      <div class="hexagon-item">
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <a href="donor.php?bloodType=bNeg" target="_blank" class="hex-content">
                                              <span class="hex-content-inner">
                                                  <span class="icon">
                                                    <img src="include/img/neg.png"/>
                                                    <span class="title">B-</span>
                                                  </span>
                                              </span>
                                              <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                          </a>
                                      </div>
                                      <div class="hexagon-item">
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <a href="donor.php?bloodType=bPos" target="_blank" class="hex-content">
                                              <span class="hex-content-inner">
                                                  <span class="icon">
                                                    <img src="include/img/pos.png"/>
                                                    <span class="title">B+</span>                                                  </span>
                                              </span>
                                              <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                          </a>
                                      </div>
                                      <div class="hexagon-item">
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <div class="hex-item">
                                              <div></div>
                                              <div></div>
                                              <div></div>
                                          </div>
                                          <a href="donor.php?bloodType=abNeg" target="_blank" class="hex-content">
                                              <span class="hex-content-inner">
                                                  <span class="icon">
                                                    <img src="include/img/neg.png"/>
                                                    <span class="title">AB-</span>                                                  </span>
                                              </span>
                                              <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                          </a>
                                      </div>
                                  </div>                                  <div class="hexagon-menu clear">
                                                                        <div class="hexagon-item">
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <a href="donor.php?bloodType=abPos" target="_blank" class="hex-content">
                                                                                <span class="hex-content-inner">
                                                                                    <span class="icon">
                                                                                      <img src="include/img/pos.png"/>                                                  </span>
                                                                                    <span class="title">AB+</span>
                                                                                </span>
                                                                                <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                                                            </a>
                                                                        </div>
                                                                        <div class="hexagon-item">
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <a href="donor.php?bloodType=oPos" target="_blank" class="hex-content">
                                                                                <span class="hex-content-inner">
                                                                                    <span class="icon">
                                                                                        <img src="include/img/pos.png"/>
                                                                                        <span class="title">O+</span>
                                                                                    </span>
                                                                                </span>
                                                                                <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                                                            </a>
                                                                        </div>
                                                                        <div class="hexagon-item">
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <a href="donor.php?bloodType=aNeg" target="_blank" class="hex-content">
                                                                                <span class="hex-content-inner">
                                                                                    <span class="icon">
                                                                                        <img src="include/img/neg.png"/>
                                                                                        <span class="title">A-</span>
                                                                                    </span>
                                                                                </span>
                                                                                <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                                                            </a>
                                                                        </div>
                                                                        <div class="hexagon-item">
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <a href="donor.php?bloodType=abPos" target="_blank" class="hex-content">
                                                                                <span class="hex-content-inner">
                                                                                    <span class="icon">
                                                                                      <img src="include/img/pos.png"/>
                                                                                      <span class="title">AB+</span>
                                                                                    </span>
                                                                                </span>
                                                                                <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                                                            </a>
                                                                        </div>
                                                                        <div class="hexagon-item">
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <a href="login.php" target="_blank" class="hex-content">
                                                                                <span class="hex-content-inner">
                                                                                    <span class="icon">
                                                                                      <img src="include/img/login.png"/>
                                                                                      <span class="title">Login</span>
                                                                                    </span>
                                                                                </span>
                                                                                <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                                                            </a>
                                                                        </div>
                                                                        <div class="hexagon-item">
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <a href="profile.php" target="_blank" class="hex-content">
                                                                                <span class="hex-content-inner">
                                                                                    <span class="icon">
                                                                                      <img src="include/img/profile.png"/>
                                                                                      <span class="title">Profile</span>                                                  </span>
                                                                                </span>
                                                                                <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                                                            </a>
                                                                        </div>
                                                                        <div class="hexagon-item">
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <div class="hex-item">
                                                                                <div></div>
                                                                                <div></div>
                                                                                <div></div>
                                                                            </div>
                                                                            <a href="reg.php" target="_blank" class="hex-content">
                                                                                <span class="hex-content-inner">
                                                                                    <span class="icon">
                                                                                      <img src="include/img/reg.png"/>
                                                                                      <span class="title">Register</span>                                                  </span>
                                                                                </span>
                                                                                <svg viewBox="0 0 173.20508075688772 200" height="200" width="174" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M86.60254037844386 0L173.20508075688772 50L173.20508075688772 150L86.60254037844386 200L0 150L0 50Z" fill="#1e2530"></path></svg>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
    </main>
</body>
</html>
