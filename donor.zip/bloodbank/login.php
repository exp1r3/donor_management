<?php
require  __DIR__.'\include\connection.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=0">
	<link rel="stylesheet" href="include/css/style.css">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="include/css/login_css/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<!-- <link rel="stylesheet" type="text/css" href="include/css/login_css/vendor/bootstrap/css/bootstrap.min.css"> -->
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="include/css/login_css/css/util.css">
	<link rel="stylesheet" type="text/css" href="include/css/login_css/css/main.css">
<!--===============================================================================================-->
</head>
<body>
	<div class="nav">
  <input type="checkbox" id="nav-check">
  <div class="nav-header">
    <div class="nav-title">
      DonorManagement
    </div>
  </div>
  <div class="nav-btn">
    <label for="nav-check">
      <span></span>
      <span></span>
      <span></span>
    </label>
  </div>

  <div class="nav-links">
    <a href="profile.php" target="_blank">Profile</a>
    <a href="login.php" target="_blank">login</a>
    <a href="reg.php" target="_blank">Register</a>
    <a href="#" target="_blank">Find Donor</a>
    <a href="logout.php" target="_blank">Logout</a>
  </div>
</div>

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="include/css/login_css/images/img-01.png" alt="IMG">
				</div>


				<form class="login100-form validate-form" action="login.php" method="POST">
					<span class="login100-form-title">
						Donor Login
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="email" placeholder="Email">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Login
						</button>
					</div>

					<?php
					if ($_SERVER['REQUEST_METHOD'] == 'POST') {
					$email=$_POST['email'];
					$password=$_POST['password'];
					$statement="SELECT * FROM donor WHERE email='$email' AND password='$password'";
					$login=$connection->query($statement);
					$row=$login->fetch_assoc();
					if($row['email']&&$row['password']){
					echo "Welcome ";
					echo $row['first_name'];
					session_start();
					$_SESSION['email']=$email;
					$_SESSION['password']=$password;
					echo"<script>window.location='profile.php'</script>";

					}
					else{
						echo"Username/Password Is Incorrect";
					}
				}
					?>

					<div class="text-center p-t-12">
						<span class="txt1">
							Forgot
						</span>
						<a class="txt2" href="#">
							Username / Password?
						</a>
					</div>

					<div class="text-center p-t-136">
						<a class="txt2" href="reg.php">
							Create your Account
							<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>




<!--===============================================================================================-->
	<script src="include/css/login_css/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="include/css/login_css/vendor/bootstrap/js/popper.js"></script>
	<script src="include/css/login_css/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="include/css/login_css/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="include/css/login_css/vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="include/css/login_css/js/main.js"></script>

</body>
</html>
